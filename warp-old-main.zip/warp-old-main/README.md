# Warp and Warp +

 این اسکریپت به طور خودکار CloudFlare WARP را در لینوکس نصب و پیکربندی می‌کند، با کلاینت رسمی WARP یا WireGuard به شبکه‌های WARP متصل می‌شود.
 
 امکان فعال کردن warp یا warp + روی IPV4 و IPV6 به صورت انتخابی.

install
```
bash <(curl -fsSL https://raw.githubusercontent.com/Abdulhossein/warp-old/main/install.sh)
```

![15](https://raw.githubusercontent.com/Ptechgithub/configs/main/media/15.jpg)

.

## اسکنر IP Warp 
## Endpoint IP scanner
```
bash <(curl -fsSL https://raw.githubusercontent.com/Abdulhossein/warp-old/main/endip/install.sh)
```
![16](https://raw.githubusercontent.com/Ptechgithub/configs/main/media/16.jpg)
[دریافت License Key رایگان](https://t.me/generatewarpplusbot)

## Credits.
[P3TERX](https://github.com/P3TERX/warp.sh) & [yonggekkk](https://github.com/yonggekkk?tab=repositories)
